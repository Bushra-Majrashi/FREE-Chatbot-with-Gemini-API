# -*- coding: utf-8 -*-


"""# chatbot w gemini api

# setup enviroment
"""


import google.generativeai as genai

GOOGLE_API_KEY = 'your API KEY'

genai.configure(api_key=GOOGLE_API_KEY)

model = genai.GenerativeModel('gemini-pro')  

"""# chatbot"""

def ask_gemini(question):
  """
  Asks Gemini a question and returns the answer.
  """
  response = model.generate_content(question)
  response.resolve()
  return response.text

question = "What is the capital of France?" #For example
answer = ask_gemini(question)
print(f"Question: {question}")
print(f"Answer: {answer}")

